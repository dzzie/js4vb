console.log(form.caption)
Form.Caption = 'test from vb!'
form.dlg.showopen 
print("file: " + form.dlg.filename)
fso = new ActiveXObject("Scripting.FileSystemObject")
print(fso)
print("c:\windows exists? " + fso.folderexists("c:\\windows"))

//show parse error line
z=}









