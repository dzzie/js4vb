print("x =", 10, "y =", 20)
var obj = {name: "John", age: 30}
print(obj) 
var arr = [1, 2, 3, 4, 5]
print(arr)
var data = {
    users: ["Alice", "Bob"],
    count: 2
}
print(data)  
alert(data)
print(prompt("Enter your name"))

var name = "John"; 
var age = 30;

x = format("Hello {name}, you are {age} years old")
alert(x)

printf("Hello {name}, you are {age} years old")









